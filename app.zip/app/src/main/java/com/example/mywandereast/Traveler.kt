package com.example.mywandereast

data class Traveler (
    var userEmail: String?= null,
    var userId: String?= null,
    var userName: String?= null,
    var userPassword: String?= null,
    var userPhone: String?= null
)