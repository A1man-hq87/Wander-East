package com.example.mywandereast

class feedback (
    var userEmail: String?= null,
    var userId: String?= null,
    var userfeedback: String?= null
)